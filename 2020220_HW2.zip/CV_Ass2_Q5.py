# %%
#%pip install numpy open3d

# %%
import numpy as np
import open3d as o3d
import os


# %%


# %%
# Path to the directory containing the .pcd files

# pcd_dir = 'path_to_your_pcd_files_directory'

pcd_dir = "./lidar_scans"

# Assuming the .pcd files are named in a sequential order
pcd_files = [f for f in os.listdir(pcd_dir) if f.endswith('.pcd')]

# Sort the files to maintain the sequence
pcd_files.sort()


# %%
# Let's list the contents of the 'camera_parameters' directory to see what files are there
camera_parameters_path = "./camera_parameters"
camera_parameters_files = os.listdir("./camera_parameters")

# %%
# Function to read normals from a text file
def read_normals(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        normals = np.array([list(map(float, line.strip().split())) for line in lines])
    return normals
# Initialize a dictionary to hold frame normals
frame_normals = {}

# Iterate over each folder in 'camera_parameters', read the normals, and store them in the dictionary
for folder_name in camera_parameters_files:
    if folder_name.endswith('.jpeg'):  # Ensure we're working with the correct directories
        normals_file_path = os.path.join(camera_parameters_path, folder_name, 'camera_normals.txt')
        if os.path.isfile(normals_file_path):  # Check if the normals file exists
            normals = read_normals(normals_file_path)
            frame_normals[folder_name] = normals

# For demonstration, let's print the normals for one of the frames
sample_frame = list(frame_normals.keys())[0]
frame_normals[sample_frame]



# %%
# Function to read normals from a text file
def read_rotation_matrix(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        normals = np.array([list(map(float, line.strip().split())) for line in lines])
    return normals
# Initialize a dictionary to hold frame normals
frames_rotation_matrix = {}

# Iterate over each folder in 'camera_parameters', read the rotation_matrix, and store them in the dictionary
for folder_name in camera_parameters_files:
    if folder_name.endswith('.jpeg'):  # Ensure we're working with the correct directories
        
        cam_normals_file_path = os.path.join(camera_parameters_path, folder_name, 'camera_normals.txt')
        cam_rotation_matrix_file_path = os.path.join(camera_parameters_path, folder_name, 'rotation_matrix.txt')
        cam_rotation_vector_file_path = os.path.join(camera_parameters_path, folder_name, 'rotation_vectors.txt')
        cam_translation_vector_file_path = os.path.join(camera_parameters_path, folder_name, 'translation_vectors.txt')
        
        if os.path.isfile(cam_rotation_matrix_file_path):  # Check if the normals file exists
            rotation_matrix = read_rotation_matrix(cam_rotation_matrix_file_path)
            frames_rotation_matrix[folder_name] = rotation_matrix

# For demonstration, let's print the normals for one of the frames
sample_frame = list(frames_rotation_matrix.keys())[0]
frames_rotation_matrix[sample_frame]


# %%
camera_parameters_files

# %%
pcd_files

# for i in range(len(pcd_files)) :
#     print(pcd_files[i])

# %%
frame_normals

# %%

def compute_plane_normal_and_offset(points):
    # Subtract the mean to center the points
    points_centered = points - np.mean(points, axis=0)

    # Calculate the covariance matrix
    H = np.dot(points_centered.T, points_centered)

    # Perform SVD
    U, S, Vt = np.linalg.svd(H)

    # The normal to the chessboard plane is the last column of V
    normal = Vt[-1, :]

    # The offset can be found by projecting the mean of the points onto the normal vector
    offset = np.dot(normal, np.mean(points, axis=0))
    
    return normal, offset




# %%

# # Storage for normals and offsets
# normals = []
# offsets = []

# # Process each .pcd file
# for idx, pcd_file in enumerate(pcd_files):
#     try:
#         # Load the point cloud data
#         pcd_path = os.path.join(pcd_dir, pcd_file)
#         pcd = o3d.io.read_point_cloud(pcd_path)

#         # Compute the normal and offset of the plane
#         normal, offset = compute_plane_normal_and_offset(np.asarray(pcd.points))
        
#         # Store the results
#         normals.append(normal)
#         offsets.append(offset)
        
#         print(f'{idx+1} Processed file {pcd_file}: Normal - {normal}')
#         print(f'{idx+1} Processed file {pcd_file}: Offset - {offset}')
        
#     except Exception as e:
#         print(f'An error occurred while processing file {pcd_file}: {e}')

# # At this point, 'normals' and 'offsets' contain the plane parameters for all .pcd files


# %%

# Storage for normals and offsets in a dictionary
LIDAR_plane_parameters = {}

# Process each .pcd file
for idx, pcd_file in enumerate(pcd_files):
    try:
        # Load the point cloud data
        pcd_path = os.path.join(pcd_dir, pcd_file)
        pcd = o3d.io.read_point_cloud(pcd_path)

        # Compute the normal and offset of the plane
        normal, offset = compute_plane_normal_and_offset(np.asarray(pcd.points))
        
        # Store the results in the dictionary with the file name as the key
        LIDAR_plane_parameters[pcd_file] = {'normal': normal, 'offset': offset}
        
        print(f'{idx+1} Processed file {pcd_file}: Normal - {normal}')
        print(f'{idx+1} Processed file {pcd_file}: Offset - {offset}')
        
    except Exception as e:
        print(f'An error occurred while processing file {pcd_file}: {e}')
        
        
print(LIDAR_plane_parameters)

# At this point, 'plane_parameters' contains the plane parameters for all .pcd files keyed by their file names


# %%


# %%


# %% [markdown]
# 

# %%



import numpy as np

def estimate_transformation(normals_L, normals_C, points_L, points_C):
    """
    Estimate the transformation from the LIDAR frame to the camera frame.
    
    Parameters:
    normals_L: List of normals in the LIDAR frame.
    normals_C: List of normals in the camera frame.
    points_L: List of points in the LIDAR frame.
    points_C: List of points in the camera frame.
    
    Returns:
    C_RL: Rotation matrix from LIDAR to camera frame.
    C_tL: Translation vector from LIDAR to camera frame.
    """
    normals_L = np.array(normals_L)
    normals_C = np.array(normals_C)
    points_L = np.array(points_L)
    points_C = np.array(points_C)
    
    # Compute cross-covariance matrix S
    S = np.zeros((3, 3))
    for n_L, n_C in zip(normals_L, normals_C):
        S += np.outer(n_L, n_C)
    
    # Perform SVD on S
    U, _, Vt = np.linalg.svd(S)
    
    # Ensure a right-handed coordinate system
    VU = Vt.T @ U.T
    if np.linalg.det(VU) < 0:
        Vt[-1, :] *= -1
        VU = Vt.T @ U.T
        
    C_RL = VU  # Rotation matrix
    
    # Translate centroids
    centroid_L = np.mean(points_L @ C_RL, axis=0)
    centroid_C = np.mean(points_C, axis=0)
    C_tL = centroid_C - centroid_L  # Translation vector
    
    return C_RL, C_tL



def project_to_image(points_L, C_RL, C_tL, camera_intrinsics):
    """
    Project LIDAR points to the camera image plane.
    
    Parameters:
    points_L: List of points in the LIDAR frame.
    C_RL: Rotation matrix from LIDAR to camera frame.
    C_tL: Translation vector from LIDAR to camera frame.
    camera_intrinsics: Camera intrinsic parameters matrix.
    
    Returns:
    points_image: Points projected onto the camera image plane.
    """
    points_L_transformed = (points_L @ C_RL.T) + C_tL
    points_image = points_L_transformed @ camera_intrinsics.T
    points_image /= points_image[:, -1:]  # Homogenize
    return points_image[:, :2]  # Return only x, y coordinates


# It seems we have a NameError because numpy is not imported in this new context.
# We need to import numpy again and try reading the camera parameters.

import numpy as np

# Redefine the reading functions with numpy imported
def read_camera_intrinsics(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        intrinsics = np.array([list(map(float, line.split())) for line in lines])
    return intrinsics

def read_distortion_coeffs(file_path):
    with open(file_path, 'r') as file:
        line = file.readline()
        coeffs = np.array(list(map(float, line.split())))
    return coeffs

# Attempt to read the camera intrinsic matrix and distortion coefficients again
camera_intrinsics = read_camera_intrinsics(camera_intrinsics_file)
distortion_coeffs = read_distortion_coeffs(distortion_coeffs_file)

camera_intrinsics, distortion_coeffs




